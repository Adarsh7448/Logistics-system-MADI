from flask import Flask, request, render_template 
from flask_sqlalchemy import SQLAlchemy 
import datetime

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///timedb.sqlite3"

db = SQLAlchemy(app)
app.app_context().push()

def date_setter(date, time):
    year, month, date = map(int,date.split("-"))
    hour, minute = map(int,time.split(":"))
    return year, month, date, hour, minute

class Show(db.Model):
    id = db.Column(db.Integer(), primary_key = True)
    name = db.Column(db.String())
    start_time = db.Column(db.DateTime())
    

@app.route("/date-time", methods = ["GET", "POST"])
def date_time():
    if request.method == "POST":
        date = request.form.get("date")
        time = request.form.get("time")  
        year, month, date, hour, minute = date_setter(date, time)     
        current_date_time = datetime.datetime(year, month, date, hour, minute)
        new_show = Show(name = "Khalnayak", start_time = current_date_time)
        db.session.add(new_show)
        db.session.commit()
        return "Added, check database"
    return render_template("get_date.html")

if __name__ == "__main__":
    app.run(debug= True)